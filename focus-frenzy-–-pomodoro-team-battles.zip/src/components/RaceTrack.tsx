import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Trophy, Zap, Flame, Flag, Users, Heart } from 'lucide-react';
import { Team } from '../types';
import { soundEngine } from '../utils/audio';

interface RaceTrackProps {
  teams: Team[];
  raceTargetHours: number;
  userTeamId: string;
  onCheerTeam: (teamId: string, emoji: string) => void;
  onSelectTeam: (teamId: string) => void;
}

interface FloatingCheer {
  id: string;
  emoji: string;
  x: number;
  teamId: string;
}

export const RaceTrack: React.FC<RaceTrackProps> = ({
  teams,
  raceTargetHours,
  userTeamId,
  onCheerTeam,
  onSelectTeam,
}) => {
  const [floatingCheers, setFloatingCheers] = useState<FloatingCheer[]>([]);

  // Rank teams by totalHours descending
  const sortedTeams = [...teams].sort((a, b) => b.totalHours - a.totalHours);

  const handleCheerClick = (e: React.MouseEvent, teamId: string, emoji: string) => {
    e.stopPropagation();
    soundEngine.playTick();
    onCheerTeam(teamId, emoji);

    const rect = e.currentTarget.getBoundingClientRect();
    const newCheer: FloatingCheer = {
      id: `${Date.now()}-${Math.random()}`,
      emoji,
      x: rect.left + rect.width / 2,
      teamId,
    };
    setFloatingCheers((prev) => [...prev, newCheer]);
    setTimeout(() => {
      setFloatingCheers((prev) => prev.filter((c) => c.id !== newCheer.id));
    }, 1200);
  };

  const getRankBadge = (rankIndex: number) => {
    switch (rankIndex) {
      case 0:
        return { label: '1ST', color: 'bg-amber-400 text-amber-950 font-bold' };
      case 1:
        return { label: '2ND', color: 'bg-slate-300 text-slate-900 font-bold' };
      case 2:
        return { label: '3RD', color: 'bg-amber-700 text-amber-100 font-bold' };
      default:
        return { label: `${rankIndex + 1}TH`, color: 'bg-slate-800 text-slate-400' };
    }
  };

  const totalCollectiveHours = teams.reduce((acc, t) => acc + t.totalHours, 0);
  const totalActiveRacers = teams.reduce(
    (acc, t) => acc + t.members.filter((m) => m.isInFocus).length,
    0
  );

  return (
    <div className="space-y-6">
      {/* Stadium Banner & Global Battle Telemetry */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-[#131b2e] to-slate-900 border border-slate-800 p-5 sm:p-6 shadow-xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-400 mb-1">
              <Flame className="w-3.5 h-3.5" />
              <span>Sprint Grand Prix · Stage 4</span>
              <span className="text-slate-600">|</span>
              <span className="text-slate-400 font-normal">Target: {raceTargetHours.toFixed(0)} Deep Work Hours</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black font-display tracking-tight text-white">
              The Focus Arena Sprint
            </h2>
            <p className="text-sm text-slate-400 max-w-xl mt-1">
              Teams advance along the speedway for every logged Pomodoro minute. Maintain flow to activate frenzy multipliers and take the lead!
            </p>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-3 gap-3 sm:gap-4 shrink-0 bg-slate-950/60 p-3 sm:p-4 rounded-xl border border-slate-800/80">
            <div>
              <div className="text-xs text-slate-400">Total Logged</div>
              <div className="text-lg sm:text-xl font-bold font-mono tabular-nums text-amber-400">
                {totalCollectiveHours.toFixed(1)}h
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-400">In Flow Now</div>
              <div className="text-lg sm:text-xl font-bold font-mono tabular-nums text-emerald-400 flex items-center gap-1">
                <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span>{totalActiveRacers}</span>
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-400">Track Leader</div>
              <div className="text-lg sm:text-xl font-bold truncate text-slate-100 flex items-center gap-1">
                <span>{sortedTeams[0]?.mascot}</span>
                <span className="truncate max-w-[80px]">{sortedTeams[0]?.name.split(' ')[0]}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Cheers Layer */}
      <div className="fixed inset-0 pointer-events-none z-50">
        <AnimatePresence>
          {floatingCheers.map((c) => (
            <motion.div
              key={c.id}
              initial={{ opacity: 1, y: 0, scale: 0.8 }}
              animate={{ opacity: 0, y: -90, scale: 1.5 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1.1, ease: 'easeOut' }}
              style={{ left: c.x }}
              className="fixed bottom-24 text-2xl font-bold drop-shadow-lg"
            >
              {c.emoji}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Racetrack Lanes */}
      <div className="bg-[#0e1526] rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl space-y-5">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-4">
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-400" />
            <h3 className="text-lg font-bold font-display text-white">Live Race Track</h3>
          </div>
          <div className="flex items-center gap-4 text-xs font-mono text-slate-400">
            <span>0h Start</span>
            <span>·</span>
            <span>{ (raceTargetHours * 0.5).toFixed(0) }h Halfway</span>
            <span>·</span>
            <span className="text-amber-400 flex items-center gap-1 font-semibold">
              <Flag className="w-3.5 h-3.5" />
              <span>{raceTargetHours.toFixed(0)}h Apex</span>
            </span>
          </div>
        </div>

        {/* Lanes Container */}
        <div className="space-y-4">
          {sortedTeams.map((team, rankIndex) => {
            const isUserTeam = team.id === userTeamId;
            const progressPercent = Math.min(100, Math.max(3, (team.totalHours / raceTargetHours) * 100));
            const activeRacers = team.members.filter((m) => m.isInFocus);
            const rank = getRankBadge(rankIndex);

            return (
              <div
                key={team.id}
                onClick={() => onSelectTeam(team.id)}
                className={`relative rounded-xl p-4 transition-all border cursor-pointer group ${
                  isUserTeam
                    ? 'bg-slate-900/90 border-amber-500/50 shadow-lg shadow-amber-500/5'
                    : 'bg-slate-900/40 border-slate-800 hover:border-slate-700 hover:bg-slate-900/60'
                }`}
              >
                {/* Lane Header Row */}
                <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] ${rank.color}`}>
                      {rank.label}
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{team.mascot}</span>
                      <span className="font-bold text-white group-hover:text-amber-300 transition-colors">
                        {team.name}
                      </span>
                      {isUserTeam && (
                        <span className="text-[11px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold">
                          YOUR SQUAD
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Team status badges */}
                  <div className="flex items-center gap-3 text-xs">
                    {team.frenzyMultiplier > 1.0 && (
                      <span className="flex items-center gap-1 text-amber-400 font-mono font-semibold animate-pulse">
                        <Zap className="w-3.5 h-3.5" />
                        <span>{team.frenzyMultiplier.toFixed(1)}x FRENZY</span>
                      </span>
                    )}

                    <div className="flex items-center gap-1.5 text-slate-400">
                      <Users className="w-3.5 h-3.5 text-slate-500" />
                      <span>{activeRacers.length} active</span>
                    </div>

                    <div className="font-mono tabular-nums font-bold text-slate-200">
                      <span className="text-amber-400 text-sm">{team.totalHours.toFixed(1)}h</span>
                      <span className="text-slate-500 text-xs"> / {raceTargetHours.toFixed(0)}h</span>
                    </div>

                    {/* Quick Cheer Button */}
                    <div className="flex items-center gap-1">
                      <button
                        onClick={(e) => handleCheerClick(e, team.id, '⚡')}
                        title="Send lightning cheer"
                        className="p-1 rounded bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-slate-300 transition-colors text-xs"
                      >
                        ⚡
                      </button>
                      <button
                        onClick={(e) => handleCheerClick(e, team.id, '🔥')}
                        title="Send fire cheer"
                        className="p-1 rounded bg-slate-800 hover:bg-rose-500 hover:text-white text-slate-300 transition-colors text-xs"
                      >
                        🔥
                      </button>
                      <button
                        onClick={(e) => handleCheerClick(e, team.id, '🚀')}
                        title="Send rocket boost"
                        className="p-1 rounded bg-slate-800 hover:bg-purple-500 hover:text-white text-slate-300 transition-colors text-xs"
                      >
                        🚀
                      </button>
                    </div>
                  </div>
                </div>

                {/* Track Speedway Lane */}
                <div className="relative h-12 w-full bg-slate-950 rounded-lg overflow-hidden border border-slate-800 flex items-center px-2">
                  
                  {/* Neon Grid Track Markings */}
                  <div className="absolute inset-0 opacity-15 pointer-events-none bg-[radial-gradient(#64748b_1px,transparent_1px)] [background-size:16px_16px]" />
                  
                  {/* Checkpoint Gates */}
                  <div className="absolute left-1/4 top-0 bottom-0 w-px bg-slate-800 border-dashed border-r border-slate-700/50 pointer-events-none" />
                  <div className="absolute left-1/2 top-0 bottom-0 w-px bg-slate-800 border-dashed border-r border-slate-700/50 pointer-events-none" />
                  <div className="absolute left-3/4 top-0 bottom-0 w-px bg-slate-800 border-dashed border-r border-slate-700/50 pointer-events-none" />
                  
                  {/* Finish Line (Right Edge) */}
                  <div className="absolute right-0 top-0 bottom-0 w-4 bg-[repeating-linear-gradient(45deg,#000,#000_4px,#fff_4px,#fff_8px)] opacity-30 pointer-events-none" />

                  {/* Filled Velocity Lane */}
                  <motion.div
                    className="absolute left-0 top-1 bottom-1 rounded-md opacity-35"
                    style={{
                      background: `linear-gradient(90deg, transparent, ${team.accentHex})`,
                    }}
                    initial={false}
                    animate={{ width: `${progressPercent}%` }}
                    transition={{ duration: 0.8, ease: 'easeOut' }}
                  />

                  {/* Active Sprinter Pod / Mascot on the track */}
                  <motion.div
                    className="absolute z-10 -ml-5 flex items-center"
                    initial={false}
                    animate={{ left: `${progressPercent}%` }}
                    transition={{ duration: 0.8, ease: 'easeOut' }}
                  >
                    <div className="relative group/racer">
                      {/* Rocket exhaust when teammates are in focus */}
                      {activeRacers.length > 0 && (
                        <div className="absolute -left-6 top-1/2 -translate-y-1/2 flex items-center pointer-events-none">
                          <span className="text-xs animate-pulse opacity-90">💨</span>
                        </div>
                      )}

                      {/* Racer Capsule */}
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center text-lg shadow-lg border relative transition-transform hover:scale-110"
                        style={{
                          backgroundColor: '#0f172a',
                          borderColor: team.accentHex,
                          boxShadow: activeRacers.length > 0 ? `0 0 16px ${team.accentHex}88` : undefined,
                        }}
                      >
                        <span>{team.mascot}</span>
                        {activeRacers.length > 0 && (
                          <span
                            className="absolute -top-1 -right-1 w-3 h-3 rounded-full border-2 border-slate-950 animate-ping"
                            style={{ backgroundColor: team.accentHex }}
                          />
                        )}
                      </div>

                      {/* Hover Tooltip with racer info */}
                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover/racer:flex flex-col items-center pointer-events-none z-30">
                        <div className="bg-slate-900 border border-slate-700 text-slate-100 text-[11px] py-1 px-2.5 rounded shadow-xl whitespace-nowrap font-mono">
                          {team.name}: {progressPercent.toFixed(1)}% ({team.totalHours.toFixed(1)}h)
                        </div>
                        <div className="w-2 h-2 bg-slate-900 border-r border-b border-slate-700 rotate-45 -mt-1" />
                      </div>
                    </div>
                  </motion.div>

                  {/* Active Teammates Mini-Avatars floating in track */}
                  {activeRacers.length > 0 && (
                    <div className="absolute right-6 flex items-center -space-x-1.5 opacity-80">
                      {activeRacers.map((m) => (
                        <div
                          key={m.id}
                          title={`${m.name} is in deep flow!`}
                          className="w-6 h-6 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs shadow"
                        >
                          {m.avatar}
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Team Tagline */}
                <div className="mt-2 flex items-center justify-between text-xs text-slate-500">
                  <span className="italic">{team.tagline}</span>
                  <span>Click squad card to view team roster</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
