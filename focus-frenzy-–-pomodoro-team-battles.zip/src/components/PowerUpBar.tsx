import React from 'react';
import { Zap, Shield, Megaphone, Sparkles } from 'lucide-react';
import { PowerUp, Team } from '../types';
import { soundEngine } from '../utils/audio';

interface PowerUpBarProps {
  powerUps: PowerUp[];
  userPoints: number;
  userTeam: Team;
  onActivatePowerUp: (powerUp: PowerUp) => void;
}

export const PowerUpBar: React.FC<PowerUpBarProps> = ({
  powerUps,
  userPoints,
  userTeam,
  onActivatePowerUp,
}) => {
  return (
    <div className="bg-[#0e1526] rounded-2xl border border-slate-800 p-5 shadow-xl space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <h4 className="text-sm font-bold font-display text-white">Focus Frenzy Spells & Boosts</h4>
        </div>
        <div className="text-xs text-slate-400 font-mono">
          Balance: <span className="font-bold text-amber-400">{userPoints} PTS</span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {powerUps.map((pw) => {
          const canAfford = userPoints >= pw.costPoints;
          const isActive = userTeam.activePowerUp?.id === pw.id;

          return (
            <div
              key={pw.id}
              className={`p-3 rounded-xl border flex flex-col justify-between transition-all ${
                isActive
                  ? 'bg-amber-500/10 border-amber-500/40 shadow-md shadow-amber-500/5'
                  : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-1.5 font-bold text-xs text-white">
                    <span className="text-base">{pw.icon}</span>
                    <span>{pw.name}</span>
                  </div>
                  <span className="text-[11px] font-mono text-amber-400 font-semibold">
                    {pw.costPoints} PTS
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-snug line-clamp-2">
                  {pw.description}
                </p>
              </div>

              <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-[10px] text-slate-500">
                  {Math.round(pw.durationSeconds / 60)}m Duration
                </span>

                <button
                  disabled={!canAfford || isActive}
                  onClick={() => {
                    soundEngine.playPowerUpChime();
                    onActivatePowerUp(pw);
                  }}
                  className={`px-2.5 py-1 text-xs rounded-lg font-semibold transition-all whitespace-nowrap ${
                    isActive
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 cursor-default'
                      : canAfford
                      ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-sm active:scale-95'
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  {isActive ? 'Active' : 'Deploy Spell'}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
