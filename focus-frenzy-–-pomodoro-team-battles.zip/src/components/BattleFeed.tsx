import React, { useState } from 'react';
import { Radio, RefreshCw, Trophy, Zap, Shield, Megaphone, Flame, MessageSquare } from 'lucide-react';
import { BattleEvent } from '../types';
import { soundEngine } from '../utils/audio';

interface BattleFeedProps {
  events: BattleEvent[];
  onTriggerSimulatedSprint: () => void;
  onSendStadiumCheer: (emoji: string) => void;
}

export const BattleFeed: React.FC<BattleFeedProps> = ({
  events,
  onTriggerSimulatedSprint,
  onSendStadiumCheer,
}) => {
  const [filter, setFilter] = useState<'all' | 'pomodoro' | 'overtake' | 'powerup'>('all');

  const filteredEvents = events.filter((evt) => {
    if (filter === 'all') return true;
    return evt.type === filter;
  });

  const getEventBadge = (type: string) => {
    switch (type) {
      case 'overtake':
        return <Trophy className="w-3.5 h-3.5 text-amber-400 shrink-0" />;
      case 'powerup':
        return <Zap className="w-3.5 h-3.5 text-purple-400 shrink-0" />;
      case 'rally':
        return <Megaphone className="w-3.5 h-3.5 text-rose-400 shrink-0" />;
      default:
        return <Flame className="w-3.5 h-3.5 text-emerald-400 shrink-0" />;
    }
  };

  return (
    <div className="bg-[#0e1526] rounded-2xl border border-slate-800 p-5 shadow-xl space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
          <Radio className="w-4 h-4 text-rose-400" />
          <h4 className="text-sm font-bold font-display text-white">Live Battle Wire</h4>
          <span className="text-xs text-slate-500 font-mono">({events.length} events)</span>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              soundEngine.playTick();
              onTriggerSimulatedSprint();
            }}
            title="Simulate rival teammate focus completion"
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 font-medium transition-colors"
          >
            <RefreshCw className="w-3 h-3 text-amber-400" />
            <span>Simulate Rival Sprint</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5">
        {(
          [
            { id: 'all', label: 'All Wire' },
            { id: 'pomodoro', label: 'Completed Blocks' },
            { id: 'overtake', label: 'Lead Changes' },
            { id: 'powerup', label: 'Spells' },
          ] as const
        ).map((item) => (
          <button
            key={item.id}
            onClick={() => {
              soundEngine.playTick();
              setFilter(item.id);
            }}
            className={`px-2.5 py-1 text-xs rounded-md font-medium transition-colors ${
              filter === item.id
                ? 'bg-slate-800 text-slate-100 border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Event Stream List */}
      <div className="space-y-2.5 max-h-[340px] overflow-y-auto pr-1">
        {filteredEvents.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-500">
            No events logged in this stream yet.
          </div>
        ) : (
          filteredEvents.map((evt) => (
            <div
              key={evt.id}
              className="p-2.5 rounded-xl bg-slate-900/50 border border-slate-850 hover:border-slate-750 transition-colors flex items-start gap-2.5 text-xs"
            >
              <div className="mt-0.5">{getEventBadge(evt.type)}</div>
              <div className="flex-1 min-w-0">
                <div className="text-slate-200 leading-relaxed break-words">
                  {evt.message}
                </div>
                <div className="mt-1 flex items-center gap-2 text-[10px] text-slate-500 font-mono">
                  <span>{evt.timestamp}</span>
                  <span>·</span>
                  <span style={{ color: evt.teamColor }} className="font-semibold">
                    {evt.teamName}
                  </span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Stadium Cheer Reaction Bar */}
      <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
        <span className="text-xs text-slate-400 font-medium flex items-center gap-1">
          <MessageSquare className="w-3.5 h-3.5 text-slate-500" />
          <span>Cheer Stadium:</span>
        </span>
        <div className="flex items-center gap-1">
          {['⚡', '🔥', '🚀', '🎯', '👑', '💪'].map((emoji) => (
            <button
              key={emoji}
              onClick={() => onSendStadiumCheer(emoji)}
              className="w-8 h-8 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 flex items-center justify-center text-sm transition-transform active:scale-90"
            >
              {emoji}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
