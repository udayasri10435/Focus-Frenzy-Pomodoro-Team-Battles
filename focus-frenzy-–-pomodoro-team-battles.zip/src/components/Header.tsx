import React from 'react';
import { Volume2, VolumeX, Sparkles, PlusCircle } from 'lucide-react';
import { AudioSettings, Team } from '../types';
import { soundEngine } from '../utils/audio';

interface HeaderProps {
  activeTab: 'stadium' | 'roster' | 'logs' | 'analytics';
  setActiveTab: (tab: 'stadium' | 'roster' | 'logs' | 'analytics') => void;
  userPoints: number;
  userTeam: Team;
  audioSettings: AudioSettings;
  onUpdateAudio: (settings: AudioSettings) => void;
  onOpenLogModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  userPoints,
  userTeam,
  audioSettings,
  onUpdateAudio,
  onOpenLogModal,
}) => {
  const toggleMute = () => {
    const nextSound = !audioSettings.soundEffects;
    onUpdateAudio({
      ...audioSettings,
      soundEffects: nextSound,
    });
    if (!nextSound) {
      soundEngine.stopAmbient();
    } else if (audioSettings.ambientSound !== 'none') {
      soundEngine.setAmbient(audioSettings.ambientSound);
    }
  };

  const navLinks: { id: 'stadium' | 'roster' | 'logs' | 'analytics'; label: string }[] = [
    { id: 'stadium', label: 'Race Arena' },
    { id: 'roster', label: 'Team Standings' },
    { id: 'logs', label: 'Work Ledger' },
    { id: 'analytics', label: 'Milestones' },
  ];

  return (
    <header className="border-b border-slate-800/80 bg-[#0c1220]/90 backdrop-blur-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        
        {/* Zone 1: Single text element Brand wordmark */}
        <div className="flex items-center gap-3">
          <div 
            onClick={() => setActiveTab('stadium')} 
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-amber-500 via-rose-500 to-purple-600 flex items-center justify-center text-white font-bold shadow-lg shadow-rose-500/20 group-hover:scale-105 transition-transform">
              <span className="text-xl leading-none">⚡</span>
            </div>
            <span className="text-xl font-extrabold tracking-tight font-display bg-gradient-to-r from-amber-300 via-rose-300 to-purple-300 bg-clip-text text-transparent">
              Focus Frenzy
            </span>
          </div>

          {/* Active Team Indicator */}
          <div className="hidden sm:flex items-center gap-2 pl-3 border-l border-slate-800 text-xs text-slate-400">
            <span>Racing for</span>
            <span className="font-semibold text-slate-200 flex items-center gap-1">
              <span>{userTeam.mascot}</span>
              <span>{userTeam.name}</span>
            </span>
          </div>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="flex items-center gap-1 sm:gap-2">
          {navLinks.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  soundEngine.playTick();
                  setActiveTab(tab.id);
                }}
                className={`px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
                  isActive
                    ? 'bg-slate-800 text-amber-300 shadow-inner border border-amber-500/20'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-2.5">
          {/* Points display */}
          <div className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono tabular-nums text-amber-400">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-semibold">{userPoints}</span>
            <span className="text-slate-500">PTS</span>
          </div>

          {/* Audio toggle button */}
          <button
            onClick={toggleMute}
            title={audioSettings.soundEffects ? 'Sound FX On (Click to mute)' : 'Sound FX Muted'}
            aria-label="Toggle sound"
            className={`p-2 rounded-lg border transition-colors ${
              audioSettings.soundEffects
                ? 'bg-slate-800/80 border-slate-700 text-amber-400 hover:bg-slate-700'
                : 'bg-slate-900 border-slate-800 text-slate-500 hover:bg-slate-800'
            }`}
          >
            {audioSettings.soundEffects ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Log Deep Work Button */}
          <button
            onClick={() => {
              soundEngine.playTick();
              onOpenLogModal();
            }}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-400 hover:to-rose-400 text-slate-950 shadow-md shadow-amber-500/15 transition-all whitespace-nowrap active:scale-95"
          >
            <PlusCircle className="w-3.5 h-3.5 text-slate-950" />
            <span>Log Deep Work</span>
          </button>
        </div>

      </div>
    </header>
  );
};
