import React, { useState } from 'react';
import { Users, UserPlus, Flame, Shield, Check, Trophy } from 'lucide-react';
import { Team, TeamMember } from '../types';
import { soundEngine } from '../utils/audio';

interface TeamRosterProps {
  teams: Team[];
  userTeamId: string;
  onSwitchTeam: (teamId: string) => void;
  onAddMember: (teamId: string, member: Omit<TeamMember, 'id'>) => void;
}

export const TeamRoster: React.FC<TeamRosterProps> = ({
  teams,
  userTeamId,
  onSwitchTeam,
  onAddMember,
}) => {
  const [selectedTeamId, setSelectedTeamId] = useState<string>(userTeamId);
  const [showAddModal, setShowAddModal] = useState<boolean>(false);

  // New member form state
  const [newMemberName, setNewMemberName] = useState<string>('');
  const [newMemberRole, setNewMemberRole] = useState<string>('Frontend Engineer');
  const [newMemberAvatar, setNewMemberAvatar] = useState<string>('⚡');

  const selectedTeam = teams.find((t) => t.id === selectedTeamId) || teams[0];

  const handleAddMemberSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemberName.trim()) return;

    soundEngine.playTick();
    onAddMember(selectedTeam.id, {
      name: newMemberName.trim(),
      role: newMemberRole.trim() || 'Contributor',
      avatar: newMemberAvatar,
      isInFocus: true,
      hoursLogged: 0.5,
      currentStreak: 1,
      lastActive: 'Just joined',
    });

    setNewMemberName('');
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Squad Navigation Selector */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {teams.map((team) => {
          const isSelected = team.id === selectedTeamId;
          const isUserTeam = team.id === userTeamId;

          return (
            <button
              key={team.id}
              onClick={() => {
                soundEngine.playTick();
                setSelectedTeamId(team.id);
              }}
              className={`p-4 rounded-xl text-left border transition-all ${
                isSelected
                  ? 'bg-slate-900 border-amber-500 shadow-md shadow-amber-500/10'
                  : 'bg-slate-900/40 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-2xl">{team.mascot}</span>
                {isUserTeam && (
                  <span className="px-1.5 py-0.5 rounded text-[10px] bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30">
                    YOUR SQUAD
                  </span>
                )}
              </div>
              <div className="font-bold text-sm text-white truncate">{team.name}</div>
              <div className="text-xs font-mono text-amber-400 font-semibold mt-1">
                {team.totalHours.toFixed(1)}h logged
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                {team.members.length} members · {team.members.filter((m) => m.isInFocus).length} in flow
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Squad Details View */}
      <div className="bg-[#0e1526] rounded-2xl border border-slate-800 p-6 shadow-xl space-y-6">
        
        {/* Banner with Squad Info & Switch Button */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
          <div className="flex items-center gap-3">
            <div
              className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl border shadow-inner"
              style={{
                backgroundColor: selectedTeam.bgHex,
                borderColor: selectedTeam.borderHex,
              }}
            >
              <span>{selectedTeam.mascot}</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-bold font-display text-white">{selectedTeam.name}</h3>
                {selectedTeam.id === userTeamId ? (
                  <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold">
                    Current Active Team
                  </span>
                ) : (
                  <button
                    onClick={() => {
                      soundEngine.playTick();
                      onSwitchTeam(selectedTeam.id);
                    }}
                    className="text-xs px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold transition-colors shadow-sm"
                  >
                    Transfer to this Squad
                  </button>
                )}
              </div>
              <p className="text-xs text-slate-400 mt-0.5 italic">{selectedTeam.tagline}</p>
            </div>
          </div>

          {/* Action to recruit teammate */}
          <button
            onClick={() => {
              soundEngine.playTick();
              setShowAddModal(true);
            }}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-slate-200 transition-colors self-start sm:self-auto"
          >
            <UserPlus className="w-4 h-4 text-amber-400" />
            <span>Recruit Teammate</span>
          </button>
        </div>

        {/* Member Roster Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {selectedTeam.members.map((member) => {
            const memberRatio = selectedTeam.totalHours > 0 
              ? Math.min(100, (member.hoursLogged / selectedTeam.totalHours) * 100) 
              : 0;

            return (
              <div
                key={member.id}
                className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 hover:border-slate-700 transition-colors flex flex-col justify-between"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-lg shadow">
                      {member.avatar}
                    </div>
                    <div>
                      <div className="font-bold text-sm text-white flex items-center gap-1.5">
                        <span>{member.name}</span>
                        {member.isUser && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono">
                            YOU
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-400">{member.role}</div>
                    </div>
                  </div>

                  {/* Flow Status */}
                  <div>
                    {member.isInFocus ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 font-mono">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                        <span>IN FLOW</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] bg-slate-800 text-slate-400 font-mono">
                        RESTING
                      </span>
                    )}
                  </div>
                </div>

                {/* Progress bar of individual deep hours contribution */}
                <div className="mt-4 pt-3 border-t border-slate-800/80">
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="text-slate-400 font-mono flex items-center gap-1">
                      <Flame className="w-3.5 h-3.5 text-amber-500" />
                      <span>{member.currentStreak}x Streak</span>
                    </span>
                    <span className="font-mono tabular-nums text-slate-200 font-semibold">
                      {member.hoursLogged.toFixed(1)}h logged ({memberRatio.toFixed(0)}%)
                    </span>
                  </div>

                  <div className="h-1.5 w-full bg-slate-950 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${memberRatio}%`,
                        backgroundColor: selectedTeam.accentHex,
                      }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>

      {/* Recruit Teammate Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0f172a] rounded-2xl border border-slate-700 p-6 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h4 className="text-base font-bold font-display text-white flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-amber-400" />
                <span>Recruit Teammate to {selectedTeam.name}</span>
              </h4>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddMemberSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Full Name / Handle
                </label>
                <input
                  type="text"
                  required
                  value={newMemberName}
                  onChange={(e) => setNewMemberName(e.target.value)}
                  placeholder="e.g. Jordan Miller"
                  className="w-full px-3 py-2 text-sm bg-slate-950 border border-slate-800 rounded-xl text-slate-100 placeholder-slate-600 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Role / Specialty
                </label>
                <input
                  type="text"
                  value={newMemberRole}
                  onChange={(e) => setNewMemberRole(e.target.value)}
                  placeholder="e.g. Frontend Specialist"
                  className="w-full px-3 py-2 text-sm bg-slate-950 border border-slate-800 rounded-xl text-slate-100 placeholder-slate-600 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Mascot / Avatar
                </label>
                <div className="flex items-center gap-2">
                  {['⚡', '🚀', '🔥', '🌊', '🦅', '🐺', '🦊', '🦾', '🎯'].map((emoji) => (
                    <button
                      key={emoji}
                      type="button"
                      onClick={() => setNewMemberAvatar(emoji)}
                      className={`w-9 h-9 rounded-lg border text-lg flex items-center justify-center transition-colors ${
                        newMemberAvatar === emoji
                          ? 'border-amber-500 bg-amber-500/20'
                          : 'border-slate-800 bg-slate-900 hover:bg-slate-800'
                      }`}
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-xs rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs rounded-xl bg-amber-500 hover:bg-amber-400 font-bold text-slate-950 transition-colors shadow-md shadow-amber-500/20"
                >
                  Confirm Recruitment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
