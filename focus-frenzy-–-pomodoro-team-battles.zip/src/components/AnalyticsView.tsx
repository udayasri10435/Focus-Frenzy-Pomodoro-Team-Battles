import React from 'react';
import { Trophy, Award, Flame, BarChart3, PieChart, Target, CheckCircle2, Lock } from 'lucide-react';
import { Team, SessionRecord, Milestone } from '../types';
import { INITIAL_MILESTONES } from '../data/initialData';

interface AnalyticsViewProps {
  teams: Team[];
  sessions: SessionRecord[];
  raceTargetHours: number;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  teams,
  sessions,
  raceTargetHours,
}) => {
  // Category breakdown calculation
  const categoryCounts: Record<string, number> = {};
  sessions.forEach((s) => {
    categoryCounts[s.category] = (categoryCounts[s.category] || 0) + s.durationMinutes;
  });

  const totalLoggedMinutes = Object.values(categoryCounts).reduce((a, b) => a + b, 0);

  const categoryBreakdown = Object.entries(categoryCounts).map(([cat, mins]) => ({
    category: cat,
    minutes: mins,
    hours: (mins / 60).toFixed(1),
    percent: totalLoggedMinutes > 0 ? Math.round((mins / totalLoggedMinutes) * 100) : 0,
  })).sort((a, b) => b.minutes - a.minutes);

  const categoryColors: Record<string, string> = {
    'Engineering': '#f59e0b',
    'Design': '#a855f7',
    'Architecture': '#06b6d4',
    'Writing & Research': '#10b981',
    'Strategy': '#f43f5e',
    'Bug Crunch': '#ef4444',
  };

  const maxTeamHours = Math.max(...teams.map((t) => t.totalHours), 1);

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-[#0e1526] rounded-2xl border border-slate-800 p-6 shadow-xl">
        <div className="flex items-center gap-3 mb-2">
          <Trophy className="w-5 h-5 text-amber-400" />
          <h3 className="text-xl font-bold font-display text-white">Grand Prix Arena Analytics</h3>
        </div>
        <p className="text-xs text-slate-400">
          In-depth distribution of team hours, work disciplines, and unlocked tournament accolades.
        </p>
      </div>

      {/* Grid: Team Comparison & Discipline Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Comparative Team Hours Chart */}
        <div className="bg-[#0e1526] rounded-2xl border border-slate-800 p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
            <h4 className="text-sm font-bold font-display text-white flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-amber-400" />
              <span>Squad Velocity Comparison</span>
            </h4>
            <span className="text-xs text-slate-400 font-mono">Target: {raceTargetHours}h</span>
          </div>

          <div className="space-y-4 pt-2">
            {teams.map((team) => {
              const widthPct = Math.min(100, (team.totalHours / raceTargetHours) * 100);

              return (
                <div key={team.id} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-200 flex items-center gap-1.5">
                      <span>{team.mascot}</span>
                      <span>{team.name}</span>
                    </span>
                    <span className="font-mono tabular-nums text-slate-300 font-semibold">
                      <span className="text-amber-400">{team.totalHours.toFixed(1)}h</span>
                      <span className="text-slate-500"> ({widthPct.toFixed(0)}%)</span>
                    </span>
                  </div>

                  <div className="h-3 w-full bg-slate-950 rounded-full overflow-hidden p-0.5 border border-slate-800">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${widthPct}%`,
                        backgroundColor: team.accentHex,
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Work Discipline Proportions */}
        <div className="bg-[#0e1526] rounded-2xl border border-slate-800 p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
            <h4 className="text-sm font-bold font-display text-white flex items-center gap-2">
              <PieChart className="w-4 h-4 text-purple-400" />
              <span>Work Category Allocation</span>
            </h4>
            <span className="text-xs text-slate-400 font-mono">
              {(totalLoggedMinutes / 60).toFixed(1)} Total Hours
            </span>
          </div>

          {/* Proportional Segment Bar */}
          <div className="h-4 w-full bg-slate-950 rounded-full overflow-hidden flex p-0.5 border border-slate-800">
            {categoryBreakdown.map((item) => (
              <div
                key={item.category}
                style={{
                  width: `${item.percent}%`,
                  backgroundColor: categoryColors[item.category] || '#64748b',
                }}
                className="h-full first:rounded-l-full last:rounded-r-full transition-all duration-500"
                title={`${item.category}: ${item.percent}%`}
              />
            ))}
          </div>

          {/* Category Legend list */}
          <div className="space-y-2 pt-2">
            {categoryBreakdown.map((item) => (
              <div key={item.category} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span
                    className="w-2.5 h-2.5 rounded-full"
                    style={{ backgroundColor: categoryColors[item.category] || '#64748b' }}
                  />
                  <span className="text-slate-300 font-medium">{item.category}</span>
                </div>
                <div className="flex items-center gap-2 font-mono tabular-nums text-slate-400">
                  <span>{item.hours}h</span>
                  <span className="text-slate-600">·</span>
                  <span className="font-semibold text-slate-200">{item.percent}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Tournament Milestones & Trophies */}
      <div className="bg-[#0e1526] rounded-2xl border border-slate-800 p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <h4 className="text-sm font-bold font-display text-white flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-400" />
            <span>Tournament Milestones</span>
          </h4>
          <span className="text-xs text-slate-400">Unlock by advancing squad hours</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {INITIAL_MILESTONES.map((milestone) => {
            const leadingHours = teams.reduce((max, t) => Math.max(max, t.totalHours), 0);
            const isUnlocked = leadingHours >= milestone.hoursRequired;
            const progress = Math.min(100, Math.round((leadingHours / milestone.hoursRequired) * 100));

            return (
              <div
                key={milestone.id}
                className={`p-4 rounded-xl border flex flex-col justify-between transition-all ${
                  isUnlocked
                    ? 'bg-amber-500/10 border-amber-500/40 shadow-sm'
                    : 'bg-slate-900/40 border-slate-800 opacity-75'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-2xl">{milestone.icon}</span>
                    {isUnlocked ? (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-400 text-slate-950 font-mono flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        UNLOCKED
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-400 font-mono flex items-center gap-1">
                        <Lock className="w-3 h-3" />
                        LOCKED
                      </span>
                    )}
                  </div>
                  <h5 className="font-bold text-sm text-white">{milestone.title}</h5>
                  <p className="text-xs text-slate-400 mt-1 leading-snug">{milestone.description}</p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/80">
                  <div className="flex items-center justify-between text-[11px] font-mono mb-1 text-slate-400">
                    <span>Target: {milestone.hoursRequired}h</span>
                    <span className="text-amber-400 font-semibold">{progress}%</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-950 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-amber-400 rounded-full transition-all"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
