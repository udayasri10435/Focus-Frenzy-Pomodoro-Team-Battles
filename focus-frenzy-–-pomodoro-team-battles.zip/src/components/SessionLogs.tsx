import React, { useState } from 'react';
import { Download, Search, Filter, Trash2, Clock, Calendar, CheckCircle2 } from 'lucide-react';
import { SessionRecord, TaskCategory } from '../types';
import { soundEngine } from '../utils/audio';

interface SessionLogsProps {
  sessions: SessionRecord[];
  onDeleteSession?: (id: string) => void;
}

const CATEGORIES: ('All' | TaskCategory)[] = [
  'All',
  'Engineering',
  'Design',
  'Writing & Research',
  'Architecture',
  'Strategy',
  'Bug Crunch',
];

export const SessionLogs: React.FC<SessionLogsProps> = ({
  sessions,
  onDeleteSession,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<'All' | TaskCategory>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredSessions = sessions.filter((s) => {
    const matchesCat = selectedCategory === 'All' || s.category === selectedCategory;
    const matchesSearch =
      s.taskTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.memberName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const totalMinutes = sessions.reduce((acc, s) => acc + s.durationMinutes, 0);
  const totalHours = (totalMinutes / 60).toFixed(1);
  const avgMinutes = sessions.length > 0 ? Math.round(totalMinutes / sessions.length) : 0;

  const exportCSV = () => {
    soundEngine.playTick();
    const headers = ['ID,Team,Member,Task,Category,DurationMinutes,Points,CompletedAt,Type'];
    const rows = sessions.map((s) =>
      `"${s.id}","${s.teamId}","${s.memberName}","${s.taskTitle.replace(/"/g, '""')}","${s.category}",${s.durationMinutes},${s.pointsEarned},"${s.completedAt}","${s.type}"`
    );
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `focus_frenzy_ledger_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportJSON = () => {
    soundEngine.playTick();
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(sessions, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `focus_frenzy_ledger_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.removeChild(downloadAnchor);
  };

  return (
    <div className="bg-[#0e1526] rounded-2xl border border-slate-800 p-6 shadow-xl space-y-6">
      
      {/* Header & Export Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
        <div>
          <h3 className="text-xl font-bold font-display text-white">Deep Work Ledger</h3>
          <p className="text-xs text-slate-400 mt-1">
            Complete verifiable log of every Pomodoro sprint submitted across the arena.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={exportJSON}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export JSON</span>
          </button>
        </div>
      </div>

      {/* Summary Stat Bars */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-850 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">Total Sprints Logged</div>
            <div className="text-xl font-bold font-mono tabular-nums text-white mt-0.5">
              {sessions.length}
            </div>
          </div>
          <CheckCircle2 className="w-6 h-6 text-amber-400/50" />
        </div>

        <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-850 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">Accumulated Deep Hours</div>
            <div className="text-xl font-bold font-mono tabular-nums text-amber-400 mt-0.5">
              {totalHours}h
            </div>
          </div>
          <Clock className="w-6 h-6 text-amber-400/50" />
        </div>

        <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-850 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">Avg Sprint Cadence</div>
            <div className="text-xl font-bold font-mono tabular-nums text-emerald-400 mt-0.5">
              {avgMinutes} min
            </div>
          </div>
          <Calendar className="w-6 h-6 text-emerald-400/50" />
        </div>
      </div>

      {/* Filters & Search Row */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Category Pills (functional filter buttons) */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => {
                soundEngine.playTick();
                setSelectedCategory(cat);
              }}
              className={`px-3 py-1 text-xs font-medium rounded-lg whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative min-w-[220px]">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search tasks or members..."
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-lg text-slate-200 placeholder-slate-600 focus:outline-none focus:border-amber-500"
          />
        </div>
      </div>

      {/* Table of Sessions */}
      <div className="overflow-x-auto rounded-xl border border-slate-800/80">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950/80 text-slate-400 uppercase font-mono tracking-wider border-b border-slate-800">
            <tr>
              <th className="py-3 px-4">Task & Objective</th>
              <th className="py-3 px-4">Discipline</th>
              <th className="py-3 px-4">Contributor</th>
              <th className="py-3 px-4 text-right">Duration</th>
              <th className="py-3 px-4 text-right">Points</th>
              <th className="py-3 px-4">Completed</th>
              {onDeleteSession && <th className="py-3 px-4 text-right">Action</th>}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 bg-slate-900/30">
            {filteredSessions.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-8 text-center text-slate-500">
                  No sessions match the selected criteria.
                </td>
              </tr>
            ) : (
              filteredSessions.map((session) => (
                <tr key={session.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4 font-semibold text-slate-100 max-w-xs truncate">
                    {session.taskTitle}
                  </td>
                  <td className="py-3 px-4 text-slate-400">
                    {session.category}
                  </td>
                  <td className="py-3 px-4 text-slate-300 font-medium">
                    {session.memberName}
                  </td>
                  <td className="py-3 px-4 text-right font-mono tabular-nums text-amber-400 font-semibold">
                    {session.durationMinutes}m
                  </td>
                  <td className="py-3 px-4 text-right font-mono tabular-nums text-purple-400 font-semibold">
                    +{session.pointsEarned}
                  </td>
                  <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">
                    {session.completedAt}
                  </td>
                  {onDeleteSession && (
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => {
                          soundEngine.playTick();
                          onDeleteSession(session.id);
                        }}
                        title="Delete log entry"
                        className="text-slate-500 hover:text-rose-400 p-1 rounded transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  )}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

    </div>
  );
};
