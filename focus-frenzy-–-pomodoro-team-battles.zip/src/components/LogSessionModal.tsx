import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { PlusCircle, Clock, Tag, User, Sparkles } from 'lucide-react';
import { TaskCategory, Team, SessionType } from '../types';
import { soundEngine } from '../utils/audio';

interface LogSessionModalProps {
  isOpen: boolean;
  onClose: () => void;
  userTeam: Team;
  onSubmit: (data: {
    taskTitle: string;
    category: TaskCategory;
    durationMinutes: number;
    type: SessionType;
    pointsEarned: number;
  }) => void;
}

const CATEGORIES: TaskCategory[] = [
  'Engineering',
  'Design',
  'Writing & Research',
  'Architecture',
  'Strategy',
  'Bug Crunch',
];

export const LogSessionModal: React.FC<LogSessionModalProps> = ({
  isOpen,
  onClose,
  userTeam,
  onSubmit,
}) => {
  const [taskTitle, setTaskTitle] = useState<string>('');
  const [category, setCategory] = useState<TaskCategory>('Engineering');
  const [durationMinutes, setDurationMinutes] = useState<number>(25);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim() || durationMinutes <= 0) return;

    soundEngine.playVictoryFanfare();
    confetti({
      particleCount: 70,
      spread: 60,
      origin: { y: 0.6 },
    });

    const basePoints = durationMinutes * 2.5;
    const frenzyBonus = basePoints * (userTeam.frenzyMultiplier - 1);
    const points = Math.round(basePoints + frenzyBonus);

    onSubmit({
      taskTitle: taskTitle.trim(),
      category,
      durationMinutes,
      type: 'focus',
      pointsEarned: points,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#0e1526] rounded-2xl border border-slate-700 p-6 max-w-md w-full shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <PlusCircle className="w-5 h-5 text-amber-400" />
            <h3 className="text-base font-bold font-display text-white">
              Log Deep Work Sprint
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white text-lg font-bold"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          
          {/* Target Squad display */}
          <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">Credited Squad:</span>
            <span className="font-bold text-white flex items-center gap-1.5">
              <span>{userTeam.mascot}</span>
              <span>{userTeam.name}</span>
            </span>
          </div>

          {/* Task Title */}
          <div>
            <label className="block font-semibold text-slate-300 mb-1">
              Task or Goal Accomplished
            </label>
            <input
              type="text"
              required
              value={taskTitle}
              onChange={(e) => setTaskTitle(e.target.value)}
              placeholder="e.g. Optimized SQL join queries on production DB"
              className="w-full px-3 py-2 text-sm bg-slate-950 border border-slate-800 rounded-xl text-slate-100 placeholder-slate-600 focus:outline-none focus:border-amber-500"
            />
          </div>

          {/* Category */}
          <div>
            <label className="block font-semibold text-slate-300 mb-1">
              Discipline
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as TaskCategory)}
              className="w-full px-3 py-2 text-sm bg-slate-950 border border-slate-800 rounded-xl text-slate-100 focus:outline-none focus:border-amber-500"
            >
              {CATEGORIES.map((c) => (
                <option key={c} value={c} className="bg-slate-900 text-slate-100">
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* Duration Minutes */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="font-semibold text-slate-300">
                Focus Duration (Minutes)
              </label>
              <span className="font-mono text-amber-400 font-bold">
                {durationMinutes} min ({(durationMinutes / 60).toFixed(2)}h)
              </span>
            </div>
            
            <div className="flex items-center gap-2">
              <input
                type="range"
                min={5}
                max={120}
                step={5}
                value={durationMinutes}
                onChange={(e) => setDurationMinutes(parseInt(e.target.value, 10))}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            <div className="flex items-center gap-1.5 mt-2">
              {[15, 25, 50, 90].map((quick) => (
                <button
                  type="button"
                  key={quick}
                  onClick={() => setDurationMinutes(quick)}
                  className={`px-2 py-1 rounded text-[11px] font-mono transition-colors ${
                    durationMinutes === quick
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  {quick}m
                </button>
              ))}
            </div>
          </div>

          {/* Points preview */}
          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5 text-amber-300">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Sprint Reward:</span>
            </div>
            <span className="font-mono font-bold text-amber-400">
              +{Math.round(durationMinutes * 2.5 * userTeam.frenzyMultiplier)} Points
            </span>
          </div>

          {/* Footer buttons */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs rounded-xl bg-amber-500 hover:bg-amber-400 font-bold text-slate-950 transition-colors shadow-md shadow-amber-500/20"
            >
              Submit to Grand Prix
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
