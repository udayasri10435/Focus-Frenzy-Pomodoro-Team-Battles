import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  FastForward, 
  Plus, 
  Shield, 
  Zap, 
  Music, 
  Sparkles,
  Flame,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { SessionType, TaskCategory, Team, AudioSettings } from '../types';
import { soundEngine } from '../utils/audio';

interface PomodoroTimerProps {
  userTeam: Team;
  onSessionComplete: (record: {
    taskTitle: string;
    category: TaskCategory;
    durationMinutes: number;
    type: SessionType;
    pointsEarned: number;
  }) => void;
  audioSettings: AudioSettings;
  onUpdateAudio: (settings: AudioSettings) => void;
  userPoints: number;
  onUsePowerUp: (powerUpId: string) => void;
}

const CATEGORIES: TaskCategory[] = [
  'Engineering',
  'Design',
  'Writing & Research',
  'Architecture',
  'Strategy',
  'Bug Crunch',
];

export const PomodoroTimer: React.FC<PomodoroTimerProps> = ({
  userTeam,
  onSessionComplete,
  audioSettings,
  onUpdateAudio,
}) => {
  // Timer settings
  const [focusMinutes, setFocusMinutes] = useState<number>(25);
  const [breakMinutes, setBreakMinutes] = useState<number>(5);
  const [customInput, setCustomInput] = useState<string>('25');
  const [isCustomMode, setIsCustomMode] = useState<boolean>(false);

  // Timer dynamic state
  const [sessionType, setSessionType] = useState<SessionType>('focus');
  const [secondsRemaining, setSecondsRemaining] = useState<number>(25 * 60);
  const [totalSecondsForPhase, setTotalSecondsForPhase] = useState<number>(25 * 60);
  const [isRunning, setIsRunning] = useState<boolean>(false);

  // Task objective
  const [taskTitle, setTaskTitle] = useState<string>('Refactor system state & core loops');
  const [category, setCategory] = useState<TaskCategory>('Engineering');

  // Distraction shield & tab blurring
  const [distractionCount, setDistractionCount] = useState<number>(0);
  const [showDistractionWarning, setShowDistractionWarning] = useState<boolean>(false);

  // Streak counter
  const [completedCyclesToday, setCompletedCyclesToday] = useState<number>(3);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Total duration in minutes completed during current phase
  const initialPhaseMinutesRef = useRef<number>(25);

  // Tab visibility listener for distraction detection
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden && isRunning && sessionType === 'focus') {
        setDistractionCount((prev) => prev + 1);
        setShowDistractionWarning(true);
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, [isRunning, sessionType]);

  // Main countdown loop
  useEffect(() => {
    if (isRunning) {
      timerRef.current = setInterval(() => {
        setSecondsRemaining((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            handlePhaseCompletion();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning, sessionType, taskTitle, category, focusMinutes, breakMinutes]);

  const handlePhaseCompletion = () => {
    setIsRunning(false);

    if (sessionType === 'focus') {
      if (audioSettings.soundEffects) soundEngine.playVictoryFanfare();
      
      // Burst celebratory confetti
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#f59e0b', '#f43f5e', '#a855f7', '#06b6d4'],
      });

      const minutesLogged = initialPhaseMinutesRef.current;
      const basePoints = minutesLogged * 2.5;
      const frenzyBonus = basePoints * (userTeam.frenzyMultiplier - 1);
      const points = Math.round(basePoints + frenzyBonus);

      onSessionComplete({
        taskTitle: taskTitle || 'Deep Work Sprint',
        category,
        durationMinutes: minutesLogged,
        type: 'focus',
        pointsEarned: points,
      });

      setCompletedCyclesToday((c) => c + 1);

      // Transition to break
      setSessionType('shortBreak');
      const nextBreakSecs = breakMinutes * 60;
      setSecondsRemaining(nextBreakSecs);
      setTotalSecondsForPhase(nextBreakSecs);
      initialPhaseMinutesRef.current = breakMinutes;
    } else {
      if (audioSettings.soundEffects) soundEngine.playBreakChime();
      
      // Transition back to focus
      setSessionType('focus');
      const nextFocusSecs = focusMinutes * 60;
      setSecondsRemaining(nextFocusSecs);
      setTotalSecondsForPhase(nextFocusSecs);
      initialPhaseMinutesRef.current = focusMinutes;
    }
  };

  const handleStartPause = () => {
    if (audioSettings.soundEffects) soundEngine.playTick();
    if (!isRunning) {
      if (audioSettings.soundEffects) soundEngine.playStartChime();
      setIsRunning(true);
      setShowDistractionWarning(false);
    } else {
      setIsRunning(false);
    }
  };

  const handleReset = () => {
    if (audioSettings.soundEffects) soundEngine.playTick();
    setIsRunning(false);
    const secs = (sessionType === 'focus' ? focusMinutes : breakMinutes) * 60;
    setSecondsRemaining(secs);
    setTotalSecondsForPhase(secs);
    initialPhaseMinutesRef.current = sessionType === 'focus' ? focusMinutes : breakMinutes;
  };

  const handleSkip = () => {
    if (audioSettings.soundEffects) soundEngine.playTick();
    handlePhaseCompletion();
  };

  const handleAddFiveMinutes = () => {
    if (audioSettings.soundEffects) soundEngine.playTick();
    setSecondsRemaining((prev) => prev + 300);
    setTotalSecondsForPhase((prev) => prev + 300);
  };

  const setPreset = (focus: number, breakM: number) => {
    soundEngine.playTick();
    setIsRunning(false);
    setIsCustomMode(false);
    setFocusMinutes(focus);
    setBreakMinutes(breakM);
    setSessionType('focus');
    const secs = focus * 60;
    setSecondsRemaining(secs);
    setTotalSecondsForPhase(secs);
    initialPhaseMinutesRef.current = focus;
  };

  const applyCustomMinutes = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseInt(customInput, 10);
    if (!isNaN(val) && val >= 1 && val <= 120) {
      soundEngine.playTick();
      setIsRunning(false);
      setIsCustomMode(true);
      setFocusMinutes(val);
      const bM = Math.max(2, Math.round(val * 0.2));
      setBreakMinutes(bM);
      setSessionType('focus');
      const secs = val * 60;
      setSecondsRemaining(secs);
      setTotalSecondsForPhase(secs);
      initialPhaseMinutesRef.current = val;
    }
  };

  const handleAmbientChange = (ambient: 'none' | 'rain' | 'drone' | 'cafe') => {
    soundEngine.playTick();
    onUpdateAudio({ ...audioSettings, ambientSound: ambient });
    soundEngine.setAmbient(ambient);
  };

  // Math for Circular Progress Ring
  const radius = 105;
  const circumference = 2 * Math.PI * radius;
  const progressRatio = totalSecondsForPhase > 0 ? (totalSecondsForPhase - secondsRemaining) / totalSecondsForPhase : 0;
  const strokeDashoffset = circumference - progressRatio * circumference;

  const minutes = Math.floor(secondsRemaining / 60);
  const seconds = secondsRemaining % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const isFocus = sessionType === 'focus';

  return (
    <div className="bg-[#0e1526] rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl space-y-6">
      
      {/* Top Cockpit Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base font-bold font-display text-white flex items-center gap-2">
              <span>Pomodoro Battle Cockpit</span>
              <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                {isFocus ? '⚡ DEEP WORK' : '☕ SQUAD REST'}
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Each session logged moves {userTeam.name} forward in the grand prix race.
            </p>
          </div>
        </div>

        {/* Multiplier / Frenzy pill */}
        <div className="flex items-center gap-2">
          {userTeam.frenzyMultiplier > 1.0 && (
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500/15 border border-amber-500/30 text-xs font-mono text-amber-300 font-semibold animate-pulse">
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              <span>{userTeam.frenzyMultiplier}x MULTIPLIER</span>
            </div>
          )}
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-300 font-mono">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>{completedCyclesToday} Today</span>
          </div>
        </div>
      </div>

      {/* Preset Mode Tabs */}
      <div className="flex flex-wrap items-center gap-2">
        <button
          onClick={() => setPreset(25, 5)}
          className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
            !isCustomMode && focusMinutes === 25
              ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          25m Classic
        </button>
        <button
          onClick={() => setPreset(50, 10)}
          className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
            !isCustomMode && focusMinutes === 50
              ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          50m Deep Dive
        </button>
        <button
          onClick={() => setPreset(15, 3)}
          className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
            !isCustomMode && focusMinutes === 15
              ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          15m Blitz Sprint
        </button>

        {/* Custom minute input form */}
        <form onSubmit={applyCustomMinutes} className="flex items-center gap-1">
          <input
            type="number"
            min={1}
            max={120}
            value={customInput}
            onChange={(e) => setCustomInput(e.target.value)}
            className="w-14 px-2 py-1 text-xs bg-slate-950 border border-slate-800 rounded-lg text-slate-200 font-mono text-center focus:outline-none focus:border-amber-500"
            placeholder="Min"
          />
          <button
            type="submit"
            className={`px-2.5 py-1 text-xs rounded-lg border transition-colors ${
              isCustomMode
                ? 'bg-amber-500 text-slate-950 font-bold border-amber-500'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200 border-slate-800'
            }`}
          >
            Custom
          </button>
        </form>
      </div>

      {/* Objective & Category Form */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="md:col-span-2">
          <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
            Current Focus Mission
          </label>
          <input
            type="text"
            value={taskTitle}
            onChange={(e) => setTaskTitle(e.target.value)}
            placeholder="What challenge are you solving?"
            className="w-full px-3.5 py-2 text-sm bg-slate-950/80 border border-slate-800 rounded-xl text-slate-100 placeholder-slate-600 focus:outline-none focus:border-amber-500 transition-colors"
          />
        </div>
        <div>
          <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
            Task Discipline
          </label>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value as TaskCategory)}
            className="w-full px-3.5 py-2 text-sm bg-slate-950/80 border border-slate-800 rounded-xl text-slate-100 focus:outline-none focus:border-amber-500 transition-colors"
          >
            {CATEGORIES.map((c) => (
              <option key={c} value={c} className="bg-slate-900 text-slate-100">
                {c}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Distraction warning banner if tab switched */}
      {showDistractionWarning && isRunning && (
        <div className="flex items-center justify-between p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>
              Tab blur detected! Keep Focus Frenzy visible to preserve full team sprint momentum.
            </span>
          </div>
          <button
            onClick={() => setShowDistractionWarning(false)}
            className="text-[11px] underline hover:text-white"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Circular Gauge & Countdown Centerpiece */}
      <div className="relative flex flex-col items-center justify-center py-4">
        
        {/* Glowing backdrop when running */}
        {isRunning && (
          <div
            className="absolute w-64 h-64 rounded-full blur-3xl opacity-20 pointer-events-none transition-all duration-1000"
            style={{
              backgroundColor: isFocus ? userTeam.accentHex : '#10b981',
            }}
          />
        )}

        <div className="relative flex items-center justify-center">
          <svg className="w-64 h-64 -rotate-90 transform" viewBox="0 0 240 240">
            {/* Background track circle */}
            <circle
              cx="120"
              cy="120"
              r={radius}
              stroke="#1e293b"
              strokeWidth="10"
              fill="transparent"
            />
            {/* Animated filled progress ring */}
            <circle
              cx="120"
              cy="120"
              r={radius}
              stroke={isFocus ? userTeam.accentHex : '#10b981'}
              strokeWidth="10"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              fill="transparent"
              className="transition-[stroke-dashoffset] duration-700 ease-linear"
            />
          </svg>

          {/* Center Digital Display */}
          <div className="absolute flex flex-col items-center justify-center text-center">
            <span className="text-5xl sm:text-6xl font-black font-mono tabular-nums tracking-tight text-white drop-shadow-md">
              {formattedTime}
            </span>
            <span className="text-xs uppercase font-bold tracking-widest text-slate-400 mt-1 flex items-center gap-1">
              <span>{isFocus ? 'Deep Focus' : 'Recovery Break'}</span>
            </span>
            <span className="text-[11px] text-slate-500 font-mono mt-0.5">
              {isFocus ? `+${focusMinutes * 2} Pts potential` : 'Rest mind & stretch'}
            </span>
          </div>
        </div>

        {/* Primary Action Controls */}
        <div className="flex items-center gap-3 mt-6">
          {/* Reset */}
          <button
            onClick={handleReset}
            title="Reset timer"
            className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Main Play / Pause */}
          <button
            onClick={handleStartPause}
            className={`px-8 py-3.5 rounded-xl font-bold text-sm flex items-center gap-2 shadow-lg transition-all active:scale-95 ${
              isRunning
                ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-600/25'
                : 'bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-400 hover:to-rose-400 text-slate-950 shadow-amber-500/25'
            }`}
          >
            {isRunning ? (
              <>
                <Pause className="w-4 h-4 fill-current" />
                <span>Pause Duel</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>Engage Focus</span>
              </>
            )}
          </button>

          {/* Quick +5 Min */}
          <button
            onClick={handleAddFiveMinutes}
            title="Extend timer by 5 minutes"
            className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors flex items-center gap-1 text-xs font-mono"
          >
            <Plus className="w-4 h-4" />
            <span>5m</span>
          </button>

          {/* Skip / Next Phase */}
          <button
            onClick={handleSkip}
            title="Skip to next phase"
            className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
          >
            <FastForward className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Ambient Sound Station */}
      <div className="pt-4 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 text-slate-400">
          <Music className="w-4 h-4 text-purple-400" />
          <span className="font-semibold text-slate-300">Ambient Flow Engine:</span>
        </div>

        <div className="flex items-center gap-1.5">
          {(
            [
              { id: 'none', label: 'Off' },
              { id: 'rain', label: '🌧️ Rain & Calm' },
              { id: 'drone', label: '🧘 432Hz Drone' },
              { id: 'cafe', label: '☕ Brownian Café' },
            ] as const
          ).map((item) => (
            <button
              key={item.id}
              onClick={() => handleAmbientChange(item.id)}
              className={`px-2.5 py-1 rounded-lg text-xs transition-colors ${
                audioSettings.ambientSound === item.id
                  ? 'bg-purple-600 text-white font-semibold shadow-sm'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

    </div>
  );
};
