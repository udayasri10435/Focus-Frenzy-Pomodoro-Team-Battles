/**
 * Web Audio API synthesizer for Focus Frenzy
 * Zero external audio files required. Pure generative web audio.
 */

class SoundEngine {
  private ctx: AudioContext | null = null;
  private ambientGain: GainNode | null = null;
  private ambientSourceNodes: (AudioNode | { stop: () => void })[] = [];
  private currentAmbient: 'none' | 'rain' | 'drone' | 'cafe' = 'none';
  private masterGain: GainNode | null = null;
  private volume: number = 0.5;

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
    }
  }

  // Play crisp start chime
  public playStartChime() {
    try {
      this.initContext();
      if (!this.ctx || !this.masterGain) return;
      const now = this.ctx.currentTime;

      // Chord: C5, E5, G5, B5 (Major 7th rising arpeggio)
      const freqs = [523.25, 659.25, 783.99, 987.77];
      freqs.forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.08);

        gain.gain.setValueAtTime(0, now + idx * 0.08);
        gain.gain.linearRampToValueAtTime(0.2, now + idx * 0.08 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.08 + 0.6);

        osc.connect(gain);
        gain.connect(this.masterGain!);

        osc.start(now + idx * 0.08);
        osc.stop(now + idx * 0.08 + 0.65);
      });
    } catch {
      // Audio autoplay policy fallback
    }
  }

  // Play Pomodoro completed fanfare
  public playVictoryFanfare() {
    try {
      this.initContext();
      if (!this.ctx || !this.masterGain) return;
      const now = this.ctx.currentTime;

      // Fanfare notes: F5 -> A5 -> C6 -> F6 victory sequence
      const notes = [
        { freq: 698.46, time: 0, dur: 0.15 },
        { freq: 880.00, time: 0.14, dur: 0.15 },
        { freq: 1046.50, time: 0.28, dur: 0.2 },
        { freq: 1396.91, time: 0.45, dur: 0.8 },
      ];

      notes.forEach((note) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(note.freq, now + note.time);

        gain.gain.setValueAtTime(0, now + note.time);
        gain.gain.linearRampToValueAtTime(0.25, now + note.time + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + note.time + note.dur);

        osc.connect(gain);
        gain.connect(this.masterGain!);

        osc.start(now + note.time);
        osc.stop(now + note.time + note.dur + 0.05);
      });
    } catch {
      // Ignore
    }
  }

  // Power-up activation sound
  public playPowerUpChime() {
    try {
      this.initContext();
      if (!this.ctx || !this.masterGain) return;
      const now = this.ctx.currentTime;

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      // Quick pitch bend upward
      osc.frequency.setValueAtTime(300, now);
      osc.frequency.exponentialRampToValueAtTime(1200, now + 0.35);

      gain.gain.setValueAtTime(0.01, now);
      gain.gain.linearRampToValueAtTime(0.2, now + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.4);

      // Low pass filter to make it smooth and retro
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(1500, now);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);

      osc.start(now);
      osc.stop(now + 0.45);
    } catch {
      // Ignore
    }
  }

  // Break alert sound
  public playBreakChime() {
    try {
      this.initContext();
      if (!this.ctx || !this.masterGain) return;
      const now = this.ctx.currentTime;

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(330, now + 0.4);

      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now);
      osc.stop(now + 0.65);
    } catch {
      // Ignore
    }
  }

  // Subtle click tick
  public playTick() {
    try {
      this.initContext();
      if (!this.ctx || !this.masterGain) return;
      const now = this.ctx.currentTime;

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, now);

      gain.gain.setValueAtTime(0.03, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.03);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now);
      osc.stop(now + 0.04);
    } catch {
      // Ignore
    }
  }

  // Stop current ambient background
  public stopAmbient() {
    this.ambientSourceNodes.forEach((node) => {
      try {
        if ('stop' in node && typeof node.stop === 'function') {
          node.stop();
        } else if ('disconnect' in node) {
          (node as AudioNode).disconnect();
        }
      } catch {
        // Safe disconnect
      }
    });
    this.ambientSourceNodes = [];
    this.currentAmbient = 'none';
  }

  // Start continuous ambient generator
  public setAmbient(type: 'none' | 'rain' | 'drone' | 'cafe') {
    this.stopAmbient();
    if (type === 'none') return;

    this.initContext();
    if (!this.ctx || !this.masterGain) return;

    this.currentAmbient = type;
    const now = this.ctx.currentTime;

    this.ambientGain = this.ctx.createGain();
    this.ambientGain.gain.setValueAtTime(0.18, now);
    this.ambientGain.connect(this.masterGain);

    if (type === 'rain') {
      // White noise buffer + Bandpass filter
      const bufferSize = this.ctx.sampleRate * 2;
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }

      const whiteNoise = this.ctx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;
      whiteNoise.loop = true;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(900, now);

      const filter2 = this.ctx.createBiquadFilter();
      filter2.type = 'highpass';
      filter2.frequency.setValueAtTime(150, now);

      whiteNoise.connect(filter);
      filter.connect(filter2);
      filter2.connect(this.ambientGain);

      whiteNoise.start(now);
      this.ambientSourceNodes.push(whiteNoise);
    } else if (type === 'drone') {
      // Deep focus binaural beat: 216Hz and 220Hz (4Hz binaural theta rhythm) + 108Hz sub-bass
      const osc1 = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const oscSub = this.ctx.createOscillator();

      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(216, now);

      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(220, now);

      oscSub.type = 'sine';
      oscSub.frequency.setValueAtTime(108, now);

      const subGain = this.ctx.createGain();
      subGain.gain.setValueAtTime(0.12, now);

      osc1.connect(this.ambientGain);
      osc2.connect(this.ambientGain);
      oscSub.connect(subGain);
      subGain.connect(this.ambientGain);

      osc1.start(now);
      osc2.start(now);
      oscSub.start(now);

      this.ambientSourceNodes.push(osc1, osc2, oscSub);
    } else if (type === 'cafe') {
      // Warm brownian noise rumble
      const bufferSize = this.ctx.sampleRate * 2;
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      let lastOut = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        output[i] = (lastOut + 0.02 * white) / 1.02;
        lastOut = output[i];
        output[i] *= 3.5; // Gain compensation
      }

      const brownNoise = this.ctx.createBufferSource();
      brownNoise.buffer = noiseBuffer;
      brownNoise.loop = true;

      const lpFilter = this.ctx.createBiquadFilter();
      lpFilter.type = 'lowpass';
      lpFilter.frequency.setValueAtTime(600, now);

      brownNoise.connect(lpFilter);
      lpFilter.connect(this.ambientGain);

      brownNoise.start(now);
      this.ambientSourceNodes.push(brownNoise);
    }
  }

  public getCurrentAmbient() {
    return this.currentAmbient;
  }
}

export const soundEngine = new SoundEngine();
