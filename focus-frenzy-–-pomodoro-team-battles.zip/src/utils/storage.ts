import { Team, SessionRecord, BattleEvent, AudioSettings } from '../types';
import { INITIAL_TEAMS, INITIAL_SESSIONS, INITIAL_EVENTS } from '../data/initialData';

const STORAGE_KEYS = {
  TEAMS: 'focus_frenzy_teams_v1',
  ACTIVE_TEAM_ID: 'focus_frenzy_active_team_id_v1',
  SESSIONS: 'focus_frenzy_sessions_v1',
  EVENTS: 'focus_frenzy_events_v1',
  USER_POINTS: 'focus_frenzy_points_v1',
  AUDIO_SETTINGS: 'focus_frenzy_audio_v1',
  RACE_TARGET_HOURS: 'focus_frenzy_race_target_v1',
};

export const loadStoredTeams = (): Team[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TEAMS);
    if (raw) return JSON.parse(raw);
  } catch {
    // fallback
  }
  return INITIAL_TEAMS;
};

export const saveStoredTeams = (teams: Team[]) => {
  try {
    localStorage.setItem(STORAGE_KEYS.TEAMS, JSON.stringify(teams));
  } catch {
    // Ignore storage quota
  }
};

export const loadActiveTeamId = (): string => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ACTIVE_TEAM_ID);
    if (raw) return raw;
  } catch {
    // fallback
  }
  return 'team-volt';
};

export const saveActiveTeamId = (teamId: string) => {
  try {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_TEAM_ID, teamId);
  } catch {
    // Ignore
  }
};

export const loadStoredSessions = (): SessionRecord[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SESSIONS);
    if (raw) return JSON.parse(raw);
  } catch {
    // fallback
  }
  return INITIAL_SESSIONS;
};

export const saveStoredSessions = (sessions: SessionRecord[]) => {
  try {
    localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(sessions));
  } catch {
    // Ignore
  }
};

export const loadStoredEvents = (): BattleEvent[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.EVENTS);
    if (raw) return JSON.parse(raw);
  } catch {
    // fallback
  }
  return INITIAL_EVENTS;
};

export const saveStoredEvents = (events: BattleEvent[]) => {
  try {
    localStorage.setItem(STORAGE_KEYS.EVENTS, JSON.stringify(events));
  } catch {
    // Ignore
  }
};

export const loadUserPoints = (): number => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.USER_POINTS);
    if (raw) return parseInt(raw, 10);
  } catch {
    // fallback
  }
  return 340; // Initial welcome points for frenzy fun
};

export const saveUserPoints = (points: number) => {
  try {
    localStorage.setItem(STORAGE_KEYS.USER_POINTS, points.toString());
  } catch {
    // Ignore
  }
};

export const loadAudioSettings = (): AudioSettings => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.AUDIO_SETTINGS);
    if (raw) return JSON.parse(raw);
  } catch {
    // fallback
  }
  return {
    soundEffects: true,
    ambientSound: 'none',
    volume: 0.5,
  };
};

export const saveAudioSettings = (settings: AudioSettings) => {
  try {
    localStorage.setItem(STORAGE_KEYS.AUDIO_SETTINGS, JSON.stringify(settings));
  } catch {
    // Ignore
  }
};

export const loadRaceTarget = (): number => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.RACE_TARGET_HOURS);
    if (raw) return parseFloat(raw);
  } catch {
    // fallback
  }
  return 24.0; // 24 hours race default
};

export const saveRaceTarget = (target: number) => {
  try {
    localStorage.setItem(STORAGE_KEYS.RACE_TARGET_HOURS, target.toString());
  } catch {
    // Ignore
  }
};
