export type SessionType = 'focus' | 'shortBreak' | 'longBreak';

export type TaskCategory = 
  | 'Engineering' 
  | 'Design' 
  | 'Writing & Research' 
  | 'Architecture' 
  | 'Strategy' 
  | 'Bug Crunch';

export interface TeamMember {
  id: string;
  name: string;
  avatar: string;
  role: string;
  isUser?: boolean;
  isInFocus: boolean;
  hoursLogged: number; // in hours (e.g. 4.2)
  currentStreak: number; // consecutive completed pomodoros
  lastActive: string;
}

export interface Team {
  id: string;
  name: string;
  tagline: string;
  color: string; // Tailwind color class or hex
  accentHex: string;
  bgHex: string;
  borderHex: string;
  mascot: string; // emoji or icon symbol
  totalHours: number;
  members: TeamMember[];
  frenzyMultiplier: number; // e.g. 1.0, 1.5, 2.0
  activePowerUp?: {
    id: string;
    name: string;
    expiresAt: number; // timestamp
  };
}

export interface SessionRecord {
  id: string;
  teamId: string;
  memberName: string;
  taskTitle: string;
  category: TaskCategory;
  durationMinutes: number;
  completedAt: string;
  pointsEarned: number;
  type: SessionType;
}

export interface BattleEvent {
  id: string;
  timestamp: string;
  teamId: string;
  teamName: string;
  teamColor: string;
  message: string;
  icon: string;
  type: 'pomodoro' | 'overtake' | 'powerup' | 'rally' | 'milestone';
}

export interface PowerUp {
  id: string;
  name: string;
  description: string;
  icon: string;
  costPoints: number;
  durationSeconds: number;
  effect: 'double_points' | 'shield' | 'team_boost';
}

export interface AudioSettings {
  soundEffects: boolean;
  ambientSound: 'none' | 'rain' | 'drone' | 'cafe';
  volume: number; // 0 to 1
}

export interface Milestone {
  id: string;
  title: string;
  description: string;
  icon: string;
  hoursRequired: number;
  unlocked: boolean;
}
