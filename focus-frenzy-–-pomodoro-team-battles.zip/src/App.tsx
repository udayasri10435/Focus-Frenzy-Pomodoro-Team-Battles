import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Header } from './components/Header';
import { RaceTrack } from './components/RaceTrack';
import { PomodoroTimer } from './components/PomodoroTimer';
import { PowerUpBar } from './components/PowerUpBar';
import { BattleFeed } from './components/BattleFeed';
import { TeamRoster } from './components/TeamRoster';
import { SessionLogs } from './components/SessionLogs';
import { AnalyticsView } from './components/AnalyticsView';
import { LogSessionModal } from './components/LogSessionModal';
import { 
  Team, 
  SessionRecord, 
  BattleEvent, 
  AudioSettings, 
  PowerUp, 
  TaskCategory, 
  SessionType 
} from './types';
import { 
  INITIAL_POWERUPS 
} from './data/initialData';
import { 
  loadStoredTeams, 
  saveStoredTeams, 
  loadActiveTeamId, 
  saveActiveTeamId,
  loadStoredSessions,
  saveStoredSessions,
  loadStoredEvents,
  saveStoredEvents,
  loadUserPoints,
  saveUserPoints,
  loadAudioSettings,
  saveAudioSettings,
  loadRaceTarget
} from './utils/storage';
import { soundEngine } from './utils/audio';

export default function App() {
  // Persistent state
  const [teams, setTeams] = useState<Team[]>(loadStoredTeams);
  const [userTeamId, setUserTeamId] = useState<string>(loadActiveTeamId);
  const [sessions, setSessions] = useState<SessionRecord[]>(loadStoredSessions);
  const [events, setEvents] = useState<BattleEvent[]>(loadStoredEvents);
  const [userPoints, setUserPoints] = useState<number>(loadUserPoints);
  const [audioSettings, setAudioSettings] = useState<AudioSettings>(loadAudioSettings);
  const [raceTargetHours] = useState<number>(loadRaceTarget);

  // UI state
  const [activeTab, setActiveTab] = useState<'stadium' | 'roster' | 'logs' | 'analytics'>('stadium');
  const [isLogModalOpen, setIsLogModalOpen] = useState<boolean>(false);
  const [powerUps] = useState<PowerUp[]>(INITIAL_POWERUPS);

  // Sync state to storage
  useEffect(() => {
    saveStoredTeams(teams);
  }, [teams]);

  useEffect(() => {
    saveActiveTeamId(userTeamId);
  }, [userTeamId]);

  useEffect(() => {
    saveStoredSessions(sessions);
  }, [sessions]);

  useEffect(() => {
    saveStoredEvents(events);
  }, [events]);

  useEffect(() => {
    saveUserPoints(userPoints);
  }, [userPoints]);

  useEffect(() => {
    saveAudioSettings(audioSettings);
    soundEngine.setVolume(audioSettings.volume);
  }, [audioSettings]);

  // Current active squad
  const currentTeam = teams.find((t) => t.id === userTeamId) || teams[0];

  // Helper to add battle events to top of list
  const addEvent = (event: Omit<BattleEvent, 'id' | 'timestamp'>) => {
    const newEvent: BattleEvent = {
      ...event,
      id: `evt-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      timestamp: 'Just now',
    };
    setEvents((prev) => [newEvent, ...prev.slice(0, 49)]);
  };

  // Session completion handler
  const handleSessionComplete = (record: {
    taskTitle: string;
    category: TaskCategory;
    durationMinutes: number;
    type: SessionType;
    pointsEarned: number;
  }) => {
    const hoursAdded = record.durationMinutes / 60;
    const prevLeader = [...teams].sort((a, b) => b.totalHours - a.totalHours)[0];

    // Update teams and user contribution
    const updatedTeams = teams.map((team) => {
      if (team.id === userTeamId) {
        const updatedMembers = team.members.map((m) => {
          if (m.isUser) {
            return {
              ...m,
              hoursLogged: m.hoursLogged + hoursAdded,
              currentStreak: m.currentStreak + 1,
              isInFocus: false,
              lastActive: 'Just finished session',
            };
          }
          return m;
        });

        return {
          ...team,
          totalHours: team.totalHours + hoursAdded,
          members: updatedMembers,
        };
      }
      return team;
    });

    setTeams(updatedTeams);
    setUserPoints((p) => p + record.pointsEarned);

    // Create session record
    const newSession: SessionRecord = {
      id: `s-${Date.now()}`,
      teamId: userTeamId,
      memberName: 'You (Alex)',
      taskTitle: record.taskTitle,
      category: record.category,
      durationMinutes: record.durationMinutes,
      pointsEarned: record.pointsEarned,
      completedAt: 'Just now',
      type: record.type,
    };
    setSessions((prev) => [newSession, ...prev]);

    // Add battle wire notification
    addEvent({
      teamId: currentTeam.id,
      teamName: currentTeam.name,
      teamColor: currentTeam.accentHex,
      message: `⚡ Alex logged ${record.durationMinutes}m of deep work on "${record.taskTitle}" (+${record.pointsEarned} pts)!`,
      icon: currentTeam.mascot,
      type: 'pomodoro',
    });

    // Check for overtake
    const newLeader = [...updatedTeams].sort((a, b) => b.totalHours - a.totalHours)[0];
    if (newLeader.id === userTeamId && prevLeader.id !== userTeamId) {
      addEvent({
        teamId: currentTeam.id,
        teamName: currentTeam.name,
        teamColor: currentTeam.accentHex,
        message: `🏁 SENSATIONAL LEAD CHANGE! ${currentTeam.name} overtook ${prevLeader.name} for 1st place!`,
        icon: '🏆',
        type: 'overtake',
      });
      confetti({
        particleCount: 100,
        spread: 100,
        origin: { y: 0.4 },
      });
    }
  };

  // Simulated rival sprint
  const handleTriggerSimulatedSprint = () => {
    // Pick a non-user team
    const rivalTeams = teams.filter((t) => t.id !== userTeamId);
    const chosenTeam = rivalTeams[Math.floor(Math.random() * rivalTeams.length)] || teams[0];
    const nonUserMembers = chosenTeam.members.filter((m) => !m.isUser);
    const member = nonUserMembers[Math.floor(Math.random() * nonUserMembers.length)] || chosenTeam.members[0];

    const durations = [25, 25, 50, 15];
    const duration = durations[Math.floor(Math.random() * durations.length)];
    const hoursAdded = duration / 60;
    const points = Math.round(duration * 2.5);

    const prevLeader = [...teams].sort((a, b) => b.totalHours - a.totalHours)[0];

    const updatedTeams = teams.map((t) => {
      if (t.id === chosenTeam.id) {
        const updatedMembers = t.members.map((m) => {
          if (m.id === member.id) {
            return {
              ...m,
              hoursLogged: m.hoursLogged + hoursAdded,
              currentStreak: m.currentStreak + 1,
              isInFocus: Math.random() > 0.3,
              lastActive: 'Just finished session',
            };
          }
          return m;
        });
        return {
          ...t,
          totalHours: t.totalHours + hoursAdded,
          members: updatedMembers,
        };
      }
      return t;
    });

    setTeams(updatedTeams);

    const tasks = [
      'Zero-allocation memory pipeline',
      'API rate limiter & Token bucket',
      'Interactive canvas node renderer',
      'WebAssembly crypto verification',
      'Design tokens & Figma sync script',
    ];
    const task = tasks[Math.floor(Math.random() * tasks.length)];

    const categories: TaskCategory[] = ['Engineering', 'Architecture', 'Design', 'Strategy'];
    const cat = categories[Math.floor(Math.random() * categories.length)];

    // Add session
    const newSession: SessionRecord = {
      id: `s-sim-${Date.now()}`,
      teamId: chosenTeam.id,
      memberName: member.name,
      taskTitle: task,
      category: cat,
      durationMinutes: duration,
      pointsEarned: points,
      completedAt: 'Just now',
      type: 'focus',
    };
    setSessions((prev) => [newSession, ...prev]);

    addEvent({
      teamId: chosenTeam.id,
      teamName: chosenTeam.name,
      teamColor: chosenTeam.accentHex,
      message: `${member.avatar} ${member.name} completed a ${duration}m sprint on ${task} (+${points} pts).`,
      icon: chosenTeam.mascot,
      type: 'pomodoro',
    });

    const newLeader = [...updatedTeams].sort((a, b) => b.totalHours - a.totalHours)[0];
    if (newLeader.id !== prevLeader.id) {
      addEvent({
        teamId: newLeader.id,
        teamName: newLeader.name,
        teamColor: newLeader.accentHex,
        message: `🏁 TRACK ALERT: ${newLeader.name} just captured the 1st place crown from ${prevLeader.name}!`,
        icon: '🏆',
        type: 'overtake',
      });
    }
  };

  // Periodic automatic rival activity simulation (every 50 seconds)
  useEffect(() => {
    const interval = setInterval(() => {
      handleTriggerSimulatedSprint();
    }, 50000);

    return () => clearInterval(interval);
  }, [teams, userTeamId]);

  // Cheer team handler
  const handleCheerTeam = (teamId: string, emoji: string) => {
    const team = teams.find((t) => t.id === teamId);
    if (!team) return;

    addEvent({
      teamId: team.id,
      teamName: team.name,
      teamColor: team.accentHex,
      message: `Crowd boosted ${team.name} with ${emoji} cheering!`,
      icon: emoji,
      type: 'frenzy' as any,
    });
  };

  // Switch active team
  const handleSwitchTeam = (teamId: string) => {
    setUserTeamId(teamId);
    const targetTeam = teams.find((t) => t.id === teamId);
    if (targetTeam) {
      addEvent({
        teamId: targetTeam.id,
        teamName: targetTeam.name,
        teamColor: targetTeam.accentHex,
        message: `Alex officially transferred to ${targetTeam.name}! Velocity boost initiated.`,
        icon: '🔄',
        type: 'rally',
      });
    }
  };

  // Add teammate to squad
  const handleAddMember = (teamId: string, memberData: any) => {
    const newMemberId = `m-${Date.now()}`;
    const updatedTeams = teams.map((t) => {
      if (t.id === teamId) {
        return {
          ...t,
          members: [
            ...t.members,
            {
              ...memberData,
              id: newMemberId,
            },
          ],
        };
      }
      return t;
    });

    setTeams(updatedTeams);
    const team = teams.find((t) => t.id === teamId);

    addEvent({
      teamId,
      teamName: team?.name || 'Squad',
      teamColor: team?.accentHex || '#f59e0b',
      message: `🎉 Welcome ${memberData.name} (${memberData.role}) to ${team?.name}!`,
      icon: '🤝',
      type: 'rally',
    });
  };

  // Activate Power-Up
  const handleActivatePowerUp = (powerUp: PowerUp) => {
    if (userPoints < powerUp.costPoints) return;

    setUserPoints((p) => p - powerUp.costPoints);

    // Apply frenzy multiplier bonus
    setTeams((prev) =>
      prev.map((t) => {
        if (t.id === userTeamId) {
          return {
            ...t,
            frenzyMultiplier: Math.min(3.0, Number((t.frenzyMultiplier + 0.5).toFixed(1))),
            activePowerUp: {
              id: powerUp.id,
              name: powerUp.name,
              expiresAt: Date.now() + powerUp.durationSeconds * 1000,
            },
          };
        }
        return t;
      })
    );

    addEvent({
      teamId: currentTeam.id,
      teamName: currentTeam.name,
      teamColor: currentTeam.accentHex,
      message: `✨ ${currentTeam.name} unleashed ${powerUp.name}! Multiplier boosted!`,
      icon: powerUp.icon,
      type: 'powerup',
    });

    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.7 },
      colors: ['#f59e0b', '#a855f7'],
    });
  };

  // Delete session
  const handleDeleteSession = (id: string) => {
    setSessions((prev) => prev.filter((s) => s.id !== id));
  };

  return (
    <div className="min-h-screen bg-[#0b0f19] text-slate-100 flex flex-col font-sans selection:bg-rose-500 selection:text-white">
      
      {/* 3-Zone Standard Top Bar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        userPoints={userPoints}
        userTeam={currentTeam}
        audioSettings={audioSettings}
        onUpdateAudio={setAudioSettings}
        onOpenLogModal={() => setIsLogModalOpen(true)}
      />

      {/* Main Viewport Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        
        {/* Tab 1: Stadium (Race Arena & Pomodoro Battles) */}
        {activeTab === 'stadium' && (
          <div className="space-y-6">
            
            {/* The Animated Race Arena Speedway */}
            <RaceTrack
              teams={teams}
              raceTargetHours={raceTargetHours}
              userTeamId={userTeamId}
              onCheerTeam={handleCheerTeam}
              onSelectTeam={(teamId) => {
                setActiveTab('roster');
              }}
            />

            {/* Split Grid: Pomodoro Battler Cockpit + Live Wire Feed */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              
              {/* Left / Center: Pomodoro Duel Cockpit & Powerups (7 cols on lg) */}
              <div className="lg:col-span-7 space-y-6">
                <PomodoroTimer
                  userTeam={currentTeam}
                  onSessionComplete={handleSessionComplete}
                  audioSettings={audioSettings}
                  onUpdateAudio={setAudioSettings}
                  userPoints={userPoints}
                  onUsePowerUp={(id) => {
                    const pw = powerUps.find((p) => p.id === id);
                    if (pw) handleActivatePowerUp(pw);
                  }}
                />

                <PowerUpBar
                  powerUps={powerUps}
                  userPoints={userPoints}
                  userTeam={currentTeam}
                  onActivatePowerUp={handleActivatePowerUp}
                />
              </div>

              {/* Right: Live Battle Wire & Event Stream (5 cols on lg) */}
              <div className="lg:col-span-5 space-y-6">
                <BattleFeed
                  events={events}
                  onTriggerSimulatedSprint={handleTriggerSimulatedSprint}
                  onSendStadiumCheer={(emoji) => handleCheerTeam(userTeamId, emoji)}
                />
              </div>

            </div>
          </div>
        )}

        {/* Tab 2: Team Roster & Standings */}
        {activeTab === 'roster' && (
          <TeamRoster
            teams={teams}
            userTeamId={userTeamId}
            onSwitchTeam={handleSwitchTeam}
            onAddMember={handleAddMember}
          />
        )}

        {/* Tab 3: Deep Work Ledger (Session logs) */}
        {activeTab === 'logs' && (
          <SessionLogs
            sessions={sessions}
            onDeleteSession={handleDeleteSession}
          />
        )}

        {/* Tab 4: Analytics & Milestones */}
        {activeTab === 'analytics' && (
          <AnalyticsView
            teams={teams}
            sessions={sessions}
            raceTargetHours={raceTargetHours}
          />
        )}

      </main>

      {/* Manual Deep Work Logging Modal */}
      <LogSessionModal
        isOpen={isLogModalOpen}
        onClose={() => setIsLogModalOpen(false)}
        userTeam={currentTeam}
        onSubmit={handleSessionComplete}
      />

      {/* Quiet, clean footer without mechanical telemetry */}
      <footer className="border-t border-slate-800/80 bg-[#0c1220] py-6 mt-12 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-400">Focus Frenzy</span>
            <span>·</span>
            <span>Pomodoro Team Battle Stadium</span>
          </div>
          <div className="text-slate-500 font-mono text-[11px]">
            Target: {raceTargetHours}h Sprint Apex · Real-time generative audio enabled
          </div>
        </div>
      </footer>

    </div>
  );
}
